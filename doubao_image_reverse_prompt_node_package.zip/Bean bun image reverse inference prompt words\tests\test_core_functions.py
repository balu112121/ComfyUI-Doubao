import unittest
import os
import sys
from unittest.mock import patch, MagicMock
import yaml
from PIL import Image
import tempfile

# 添加项目根目录到Python路径
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from doubao_image_reverse_prompt import DoubaoImageReversePromptNode

class TestDoubaoImageReversePromptNode(unittest.TestCase):
    def setUp(self):
        # 创建临时配置文件
        self.temp_config = tempfile.NamedTemporaryFile(delete=False, suffix='.yaml')
        config_content = """
        doubao_api_key: "test_api_key"
        doubao_api_secret: "test_api_secret"
        default_params:
          detail_level: "medium"
          language: "zh"
          style: "natural"
        """
        self.temp_config.write(config_content.encode('utf-8'))
        self.temp_config.close()
        
        # 加载配置
        with open(self.temp_config.name, 'r', encoding='utf-8') as f:
            self.config = yaml.safe_load(f)
        
        # 创建测试节点实例
        self.node = DoubaoImageReversePromptNode(
            api_key=self.config['doubao_api_key'],
            api_secret=self.config['doubao_api_secret']
        )
        
        # 创建临时测试图像
        self.temp_image = tempfile.NamedTemporaryFile(delete=False, suffix='.jpg')
        self.temp_image.close()
        
        # 创建一个简单的测试图像
        test_img = Image.new('RGB', (100, 100), color='red')
        test_img.save(self.temp_image.name)
    
    def tearDown(self):
        # 清理临时文件
        os.unlink(self.temp_config.name)
        os.unlink(self.temp_image.name)
        
        # 清理缓存文件（如果有）
        cache_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), '.cache')
        if os.path.exists(cache_dir):
            for file in os.listdir(cache_dir):
                os.unlink(os.path.join(cache_dir, file))
            os.rmdir(cache_dir)
    
    def test_init(self):
        """测试节点初始化"""
        self.assertEqual(self.node.api_key, "test_api_key")
        self.assertEqual(self.node.api_secret, "test_api_secret")
        self.assertIsNotNone(self.node.session)
    
    @patch('requests.Session.post')
    def test_get_access_token(self, mock_post):
        """测试获取访问令牌"""
        # 模拟API响应
        mock_response = MagicMock()
        mock_response.json.return_value = {
            'data': {
                'access_token': 'test_access_token',
                'expires_in': 3600
            },
            'code': 0
        }
        mock_post.return_value = mock_response
        
        # 调用方法
        token = self.node._get_access_token()
        
        # 验证结果
        self.assertEqual(token, 'test_access_token')
        mock_post.assert_called_once()
    
    @patch('requests.Session.post')
    def test_get_access_token_error(self, mock_post):
        """测试获取访问令牌失败情况"""
        # 模拟API错误响应
        mock_response = MagicMock()
        mock_response.json.return_value = {
            'code': 401,
            'message': 'Invalid API key'
        }
        mock_post.return_value = mock_response
        
        # 验证异常
        with self.assertRaises(Exception):
            self.node._get_access_token()
    
    def test_encode_image(self):
        """测试图像编码"""
        encoded_image = self.node._encode_image(self.temp_image.name)
        self.assertIsInstance(encoded_image, str)
        self.assertTrue(len(encoded_image) > 0)
    
    def test_encode_image_file_not_found(self):
        """测试图像文件不存在情况"""
        with self.assertRaises(FileNotFoundError):
            self.node._encode_image('non_existent_image.jpg')
    
    @patch('doubao_image_reverse_prompt.DoubaoImageReversePromptNode._get_access_token')
    @patch('requests.Session.post')
    def test_reverse_infer_prompt(self, mock_post, mock_get_token):
        """测试反推提示词功能"""
        # 模拟API响应
        mock_get_token.return_value = 'test_access_token'
        
        mock_response = MagicMock()
        mock_response.json.return_value = {
            'code': 0,
            'data': {
                'prompt': '测试提示词',
                'keywords': ['测试', '图像']
            }
        }
        mock_post.return_value = mock_response
        
        # 调用方法
        result = self.node.reverse_infer_prompt(self.temp_image.name)
        
        # 验证结果
        self.assertIn('original_prompt', result)
        self.assertIn('optimized_prompt', result)
        self.assertIn('keywords', result)
        self.assertEqual(result['original_prompt'], '测试提示词')
        mock_get_token.assert_called_once()
        mock_post.assert_called_once()
    
    @patch('doubao_image_reverse_prompt.DoubaoImageReversePromptNode._get_access_token')
    @patch('requests.Session.post')
    def test_batch_process(self, mock_post, mock_get_token):
        """测试批量处理功能"""
        # 模拟API响应
        mock_get_token.return_value = 'test_access_token'
        
        mock_response = MagicMock()
        mock_response.json.return_value = {
            'code': 0,
            'data': {
                'prompt': '测试提示词',
                'keywords': ['测试', '图像']
            }
        }
        mock_post.return_value = mock_response
        
        # 调用方法
        results = self.node.batch_process([self.temp_image.name, self.temp_image.name])
        
        # 验证结果
        self.assertEqual(len(results), 2)
        for result in results:
            self.assertIn('original_prompt', result)
            self.assertIn('optimized_prompt', result)
            self.assertIn('keywords', result)
    
    def test_optimize_prompt(self):
        """测试提示词优化功能"""
        original_prompt = "这是一张红色的图片"
        optimized_prompt = self.node._optimize_prompt(original_prompt)
        
        self.assertIsInstance(optimized_prompt, str)
        self.assertTrue(len(optimized_prompt) >= len(original_prompt))
    
    def test_process_response(self):
        """测试响应处理功能"""
        response = {
            'code': 0,
            'data': {
                'prompt': '测试提示词',
                'keywords': ['测试', '图像']
            }
        }
        
        result = self.node._process_response(response)
        
        self.assertEqual(result['original_prompt'], '测试提示词')
        self.assertEqual(result['keywords'], ['测试', '图像'])
    
    def test_process_response_error(self):
        """测试处理错误响应"""
        response = {
            'code': 400,
            'message': 'Bad request'
        }
        
        with self.assertRaises(Exception) as context:
            self.node._process_response(response)
        
        self.assertIn('Bad request', str(context.exception))

if __name__ == '__main__':
    unittest.main()