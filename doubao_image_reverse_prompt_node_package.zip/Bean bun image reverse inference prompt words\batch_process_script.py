#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
豆包图像反推提示词批量处理脚本

该脚本用于批量处理多个图像文件，自动生成描述每个图像的提示词
并将结果保存到指定的输出目录或文件中。
"""

import os
import sys
import yaml
import argparse
import json
import time
from datetime import datetime
import logging
from concurrent.futures import ThreadPoolExecutor, as_completed

# 导入核心功能模块
from doubao_image_reverse_prompt import DoubaoImageReversePromptNode

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(f'batch_process_{datetime.now().strftime("%Y%m%d_%H%M%S")}.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)


def load_config(config_path='config.yaml'):
    """加载配置文件"""
    try:
        with open(config_path, 'r', encoding='utf-8') as f:
            config = yaml.safe_load(f)
        logger.info(f"配置文件加载成功: {config_path}")
        return config
    except Exception as e:
        logger.error(f"加载配置文件失败: {str(e)}")
        raise


def get_supported_image_extensions():
    """返回支持的图像文件扩展名列表"""
    return ['.jpg', '.jpeg', '.png', '.bmp', '.gif', '.webp']


def is_image_file(file_path):
    """检查文件是否为支持的图像文件"""
    ext = os.path.splitext(file_path)[1].lower()
    return ext in get_supported_image_extensions()


def find_image_files(directory):
    """查找目录中的所有图像文件"""
    image_files = []
    for root, _, files in os.walk(directory):
        for file in files:
            file_path = os.path.join(root, file)
            if is_image_file(file_path):
                image_files.append(file_path)
    logger.info(f"在目录 {directory} 中找到 {len(image_files)} 个图像文件")
    return image_files


def process_single_image(node, image_path, output_dir, detail_level, language, style):
    """处理单个图像并返回结果"""
    try:
        start_time = time.time()
        logger.info(f"开始处理图像: {image_path}")
        
        # 调用反推提示词功能
        result = node.reverse_infer_prompt(
            image_path=image_path,
            detail_level=detail_level,
            language=language,
            style=style
        )
        
        # 添加图像路径和处理时间信息
        result['image_path'] = image_path
        result['processing_time'] = time.time() - start_time
        
        # 保存结果到输出目录
        if output_dir:
            save_result(result, output_dir)
        
        logger.info(f"图像处理完成: {image_path}, 耗时: {result['processing_time']:.2f}秒")
        return result
        
    except Exception as e:
        error_info = {
            'image_path': image_path,
            'error': str(e),
            'timestamp': datetime.now().isoformat()
        }
        logger.error(f"处理图像失败: {image_path}, 错误: {str(e)}")
        return error_info


def save_result(result, output_dir):
    """保存处理结果到输出目录"""
    # 确保输出目录存在
    os.makedirs(output_dir, exist_ok=True)
    
    # 生成结果文件名
    image_basename = os.path.splitext(os.path.basename(result['image_path']))[0]
    result_file_name = f"{image_basename}_prompt_result.json"
    result_file_path = os.path.join(output_dir, result_file_name)
    
    # 保存JSON格式的结果
    with open(result_file_path, 'w', encoding='utf-8') as f:
        json.dump(result, f, ensure_ascii=False, indent=2)
    
    # 保存纯文本格式的优化提示词
    prompt_file_name = f"{image_basename}_prompt.txt"
    prompt_file_path = os.path.join(output_dir, prompt_file_name)
    with open(prompt_file_path, 'w', encoding='utf-8') as f:
        f.write(result['optimized_prompt'])
    
    # 保存关键词文件
    keywords_file_name = f"{image_basename}_keywords.txt"
    keywords_file_path = os.path.join(output_dir, keywords_file_name)
    with open(keywords_file_path, 'w', encoding='utf-8') as f:
        f.write(','.join(result['keywords']))


def batch_process_images(image_paths, config, output_dir=None, max_workers=4, 
                         detail_level="medium", language="zh", style="natural"):
    """批量处理图像文件"""
    # 创建节点实例
    node = DoubaoImageReversePromptNode(
        api_key=config['doubao_api_key'],
        api_secret=config['doubao_api_secret']
    )
    
    all_results = []
    total_images = len(image_paths)
    success_count = 0
    error_count = 0
    
    logger.info(f"开始批量处理，共 {total_images} 个图像，最大并发数: {max_workers}")
    start_time = time.time()
    
    # 使用线程池并发处理图像
    with ThreadPoolExecutor(max_workers=min(max_workers, total_images)) as executor:
        # 提交所有任务
        future_to_image = {
            executor.submit(process_single_image, node, image_path, output_dir, detail_level, language, style): image_path 
            for image_path in image_paths
        }
        
        # 处理完成的任务
        for i, future in enumerate(as_completed(future_to_image)):
            image_path = future_to_image[future]
            try:
                result = future.result()
                all_results.append(result)
                
                if 'error' not in result:
                    success_count += 1
                else:
                    error_count += 1
                
                # 显示进度
                progress = (i + 1) / total_images * 100
                logger.info(f"处理进度: {i + 1}/{total_images} ({progress:.1f}%), 成功: {success_count}, 失败: {error_count}")
                
            except Exception as e:
                logger.error(f"处理图像时发生异常: {image_path}, 异常: {str(e)}")
                error_count += 1
    
    total_time = time.time() - start_time
    logger.info(f"批量处理完成！总耗时: {total_time:.2f}秒, 平均每张: {total_time/total_images:.2f}秒")
    logger.info(f"处理统计: 总图像数: {total_images}, 成功: {success_count}, 失败: {error_count}")
    
    # 保存汇总结果
    if output_dir:
        summary_file = os.path.join(output_dir, f"batch_summary_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json")
        summary = {
            'total_images': total_images,
            'success_count': success_count,
            'error_count': error_count,
            'total_time': total_time,
            'average_time_per_image': total_time/total_images if total_images > 0 else 0,
            'timestamp': datetime.now().isoformat(),
            'results': all_results
        }
        with open(summary_file, 'w', encoding='utf-8') as f:
            json.dump(summary, f, ensure_ascii=False, indent=2)
        logger.info(f"汇总结果已保存到: {summary_file}")
    
    return all_results


def main():
    """主函数"""
    # 解析命令行参数
    parser = argparse.ArgumentParser(description='豆包图像反推提示词批量处理脚本')
    parser.add_argument('--input', '-i', required=True, help='输入图像文件或目录路径')
    parser.add_argument('--output', '-o', help='输出目录路径，默认为input目录下的output文件夹')
    parser.add_argument('--config', '-c', default='config.yaml', help='配置文件路径，默认为config.yaml')
    parser.add_argument('--workers', '-w', type=int, default=4, help='最大并发数，默认为4')
    parser.add_argument('--detail', '-d', choices=['low', 'medium', 'high'], default='medium', help='细节级别，默认为medium')
    parser.add_argument('--language', '-l', choices=['zh', 'en'], default='zh', help='生成提示词的语言，默认为zh')
    parser.add_argument('--style', '-s', choices=['natural', 'artistic', 'technical'], default='natural', help='提示词风格，默认为natural')
    
    args = parser.parse_args()
    
    try:
        # 加载配置
        config = load_config(args.config)
        
        # 确定输入图像文件列表
        if os.path.isfile(args.input):
            if not is_image_file(args.input):
                logger.error(f"输入文件不是支持的图像格式: {args.input}")
                sys.exit(1)
            image_files = [args.input]
        elif os.path.isdir(args.input):
            image_files = find_image_files(args.input)
            if not image_files:
                logger.error(f"在输入目录中未找到任何支持的图像文件: {args.input}")
                sys.exit(1)
        else:
            logger.error(f"输入路径不存在: {args.input}")
            sys.exit(1)
        
        # 确定输出目录
        if args.output:
            output_dir = args.output
        else:
            if os.path.isfile(args.input):
                output_dir = os.path.join(os.path.dirname(args.input), 'output')
            else:
                output_dir = os.path.join(args.input, 'output')
        
        # 创建输出目录
        os.makedirs(output_dir, exist_ok=True)
        logger.info(f"输出目录: {output_dir}")
        
        # 批量处理图像
        results = batch_process_images(
            image_files,
            config,
            output_dir,
            max_workers=args.workers,
            detail_level=args.detail,
            language=args.language,
            style=args.style
        )
        
        # 统计结果
        success_count = sum(1 for r in results if 'error' not in r)
        error_count = sum(1 for r in results if 'error' in r)
        
        print(f"\n批量处理完成！")
        print(f"总图像数: {len(results)}")
        print(f"成功: {success_count}")
        print(f"失败: {error_count}")
        print(f"结果保存目录: {output_dir}")
        
    except Exception as e:
        logger.error(f"批量处理过程中发生错误: {str(e)}")
        print(f"错误: {str(e)}")
        sys.exit(1)


if __name__ == '__main__':
    main()