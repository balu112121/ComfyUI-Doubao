# 豆包图像反推提示词 API 文档

## 1. 概述

本文档详细介绍了豆包图像反推提示词 API 的使用方法、参数说明和返回值格式，帮助开发者理解和集成该功能。

## 2. API 基础信息

- **服务名称**: 豆包图像反推提示词 API
- **功能描述**: 通过输入图像，自动生成描述该图像内容的提示词
- **支持格式**: JPG、PNG、WEBP 等常见图像格式

## 3. API 调用方式

### 3.1 标准 Python 版本调用

```python
from doubao_image_reverse_prompt import DoubaoImageReversePromptNode
import yaml

# 加载配置
with open('config.yaml', 'r', encoding='utf-8') as f:
    config = yaml.safe_load(f)

# 创建节点实例
node = DoubaoImageReversePromptNode(
    api_key=config['doubao_api_key'],
    api_secret=config['doubao_api_secret']
)

# 调用反推提示词方法
result = node.reverse_infer_prompt(
    image_path="path/to/image.jpg",
    detail_level="high",
    language="zh",
    style="natural"
)
```

### 3.2 ComfyUI 节点调用

在 ComfyUI 中，将节点添加到工作流后，通过界面配置参数并连接图像源即可使用。

## 4. 核心方法说明

### 4.1 reverse_infer_prompt

```python
def reverse_infer_prompt(self, image_path, detail_level="medium", language="zh", style="natural"):
    # 方法实现...
```

**参数说明**:

| 参数名 | 类型 | 默认值 | 说明 |
|-------|------|-------|------|
| image_path | str | 必填 | 图像文件路径 |
| detail_level | str | "medium" | 细节级别，可选值: "low", "medium", "high" |
| language | str | "zh" | 语言，可选值: "zh", "en" |
| style | str | "natural" | 风格，可选值: "natural", "artistic", "technical" |

**返回值**:

```python
{
    'original_prompt': str,  # 原始提示词
    'optimized_prompt': str,  # 优化后提示词
    'keywords': list,  # 提取的关键词列表
    'image_info': dict,  # 图像信息
    'processing_time': float  # 处理时间(秒)
}
```

### 4.2 batch_process

```python
def batch_process(self, image_paths, detail_level="medium", language="zh", style="natural"):
    # 方法实现...
```

**参数说明**:

| 参数名 | 类型 | 默认值 | 说明 |
|-------|------|-------|------|
| image_paths | list | 必填 | 图像文件路径列表 |
| detail_level | str | "medium" | 细节级别 |
| language | str | "zh" | 语言 |
| style | str | "natural" | 风格 |

**返回值**:

```python
[
    {
        'original_prompt': str,  # 原始提示词
        'optimized_prompt': str,  # 优化后提示词
        'keywords': list,  # 关键词
        # 其他字段同 reverse_infer_prompt
    },
    # 更多图像结果...
]
```

## 5. 错误处理

API 可能返回的常见错误及处理方式:

| 错误类型 | 错误码 | 错误信息 | 处理建议 |
|---------|-------|---------|---------|
| API 认证失败 | 401 | Invalid API key or secret | 检查 API 密钥和密钥密码是否正确 |
| 图像文件不存在 | 404 | Image file not found | 检查图像文件路径是否正确 |
| 图像格式不支持 | 415 | Unsupported image format | 转换为支持的图像格式 |
| API 调用频率超限 | 429 | Rate limit exceeded | 减少调用频率，增加重试间隔 |
| 服务器错误 | 500 | Internal server error | 稍后重试，检查日志 |
| 网络连接超时 | Timeout | Request timeout | 检查网络连接，增加超时时间 |

## 6. API 最佳实践

1. **错误处理**: 始终使用 try-except 块捕获可能的异常
2. **参数验证**: 在调用前验证图像路径和参数有效性
3. **缓存机制**: 对于重复处理的图像，使用缓存避免重复调用
4. **并发控制**: 批量处理时控制并发数，避免触发 API 频率限制
5. **错误重试**: 实现自动重试机制，处理临时性故障
6. **资源释放**: 确保处理完成后释放图像资源

## 7. 配置说明

API 支持通过配置文件自定义行为，详见 `config.yaml` 文件:

```yaml
# API配置
doubao_api_key: "your_api_key"
doubao_api_secret: "your_api_secret"

# 请求配置
request_config:
  timeout: 60  # 超时时间
  retry_count: 3  # 重试次数
  retry_delay: 5  # 重试间隔

# 更多配置项请参考 config_example.yaml
```

## 8. 性能优化建议

1. **图像预处理**: 对于大尺寸图像，预处理时适当压缩
2. **批量处理**: 合理利用 batch_process 方法处理多张图像
3. **异步调用**: 在支持的环境中，考虑使用异步调用提高效率
4. **资源管理**: 避免同时加载大量图像到内存
5. **缓存策略**: 合理设置缓存有效期，减少重复调用

## 9. 更新日志

### 版本 1.0.0
- 初始版本发布
- 支持基本图像反推提示词功能
- 提供标准 Python 版本和 ComfyUI 版本

### 版本 1.1.0
- 增加批量处理功能
- 优化提示词生成质量
- 增加配置文件支持

### 版本 1.2.0
- 添加缓存机制
- 完善错误处理
- 增加图像预处理选项

## 10. 常见问题解答

**Q: API 调用有频率限制吗?**
A: 是的，豆包 API 有调用频率限制，请参考官方文档。建议实现缓存和重试机制。

**Q: 支持哪些语言的提示词生成?**
A: 目前支持中文(zh)和英文(en)。

**Q: 最大支持多大尺寸的图像?**
A: 默认配置下最大支持 1920x1080 像素的图像，可通过配置文件调整。

**Q: 如何提高提示词质量?**
A: 可以尝试提高 detail_level 参数至 "high"，并选择适合的 style 参数。