# 豆包图像反推提示词节点

这是一个用于豆包AI的图像反推提示词工具，包含两个版本：
1. 标准Python版本
2. ComfyUI兼容版本

该工具可以从输入的图像中自动生成适合AI图像生成的提示词。

## 功能特点

- 支持从图像中提取关键信息并生成描述性提示词
- 可调整细节级别、语言和描述风格
- 批量处理多个图像（标准版本）
- 优化提示词以提高AI图像生成质量
- 配置灵活，支持自定义参数
- 完全兼容ComfyUI工作流

## 目录结构

```
├── README.md                # 项目说明文档
├── config.yaml              # 配置文件
├── doubao_image_reverse_prompt.py  # 标准Python版本
├── comfyui_doubao_image_reverse_prompt.py  # ComfyUI兼容版本
└── requirements.txt         # 依赖包列表
```

## 安装依赖

使用pip安装所需的依赖包：

```bash
pip install -r requirements.txt
```

## 配置说明

在使用前，请先编辑`config.yaml`文件，设置您的豆包API密钥和其他配置参数：

```yaml
# API配置
doubao_api_key: "your_api_key_here"  # 替换为您的豆包API密钥
doubao_api_secret: "your_api_secret_here"  # 替换为您的豆包API密钥密码

# 默认参数配置
default_detail_level: "high"  # 可选值: low, medium, high
default_language: "zh"       # 可选值: zh, en
default_style: "natural"     # 可选值: natural, artistic, technical

# API请求配置
request_timeout: 30
retry_count: 3
retry_delay: 2

# 输出配置
save_results: true
output_dir: "./results"
log_level: "INFO"  # 可选值: DEBUG, INFO, WARNING, ERROR
```

## 标准Python版本使用示例

### 基本使用

```python
from doubao_image_reverse_prompt import DoubaoImageReversePromptNode
import yaml

# 加载配置
with open('config.yaml', 'r', encoding='utf-8') as f:
    config = yaml.safe_load(f)

# 创建节点实例
node = DoubaoImageReversePromptNode(
    api_key=config['doubao_api_key'],
    api_secret=config['doubao_api_secret']
)

# 单个图像反推提示词
try:
    result = node.reverse_infer_prompt(
        "example.jpg",  # 替换为您的图像路径
        detail_level=config['default_detail_level'],
        language=config['default_language'],
        style=config['default_style']
    )
    
    print(f"原始提示词: {result['original_prompt']}")
    print(f"优化提示词: {result['optimized_prompt']}")
    print(f"关键词: {result['keywords']}")
    
except Exception as e:
    print(f"处理失败: {str(e)}")
```

### 批量处理

```python
# 批量处理多个图像
image_paths = ["image1.jpg", "image2.jpg", "image3.jpg"]
results = node.batch_process(
    image_paths,
    detail_level=config['default_detail_level'],
    language=config['default_language'],
    style=config['default_style']
)

# 处理结果
for i, result in enumerate(results):
    if 'error' in result:
        print(f"图像 {image_paths[i]} 处理失败: {result['error']}")
    else:
        print(f"\n图像 {image_paths[i]} 处理成功:")
        print(f"优化提示词: {result['optimized_prompt']}")
```

## ComfyUI版本使用说明

### 安装方法

将`comfyui_doubao_image_reverse_prompt.py`文件复制到您的ComfyUI安装目录下的`custom_nodes`文件夹中，然后重启ComfyUI。

### 节点位置

重启ComfyUI后，您可以在"提示词生成"类别下找到"豆包图像反推提示词"节点。

### 节点参数

- **image**: 输入图像（连接自其他节点的图像输出）
- **api_key**: 您的豆包API密钥
- **api_secret**: 您的豆包API密钥密码
- **detail_level**: 细节级别（高/中/低）
- **language**: 输出语言（中文/英文）
- **style**: 描述风格（自然/艺术/技术）

### 节点输出

- **原始提示词**: API返回的原始提示词
- **优化提示词**: 根据关键词和风格优化后的提示词
- **关键词**: 从图像中提取的关键词列表

### 使用示例

1. 将图像加载节点连接到"豆包图像反推提示词"节点的`image`输入
2. 输入您的API密钥和密钥密码
3. 根据需要调整其他参数
4. 将输出连接到图像生成节点的提示词输入

## 参数说明

- **detail_level**: 细节级别，可选值：`low`, `medium`, `high`
  - `low`: 生成简洁的提示词，适合快速处理
  - `medium`: 生成中等详细程度的提示词，平衡质量和速度
  - `high`: 生成最详细的提示词，包含更多图像细节
  
- **language**: 输出语言，可选值：`zh`(中文), `en`(英文)
  
- **style**: 描述风格，可选值：
  - `natural`: 自然描述风格，适合大多数场景
  - `artistic`: 艺术描述风格，适合艺术创作
  - `technical`: 技术描述风格，包含更多技术细节

## 注意事项

1. 使用前需要注册豆包API并获取API密钥和密钥密码
2. 处理大图像可能会增加处理时间和API调用成本
3. 确保您的网络环境可以访问豆包API服务
4. 请遵守相关法律法规，不要用于非法用途
5. 在ComfyUI中使用时，建议将API密钥保存到工作流模板中以便重复使用

## 常见问题

### API调用失败
- 检查API密钥和密钥密码是否正确
- 确认网络连接是否正常
- 查看错误信息，根据提示进行排查

### 提示词质量不佳
- 尝试调整`detail_level`参数
- 切换不同的`style`风格
- 确保输入图像清晰可辨

### ComfyUI中找不到节点
- 确认文件已正确放置在`custom_nodes`文件夹中
- 尝试重启ComfyUI
- 检查是否有Python依赖包未安装

## 许可证

MIT License