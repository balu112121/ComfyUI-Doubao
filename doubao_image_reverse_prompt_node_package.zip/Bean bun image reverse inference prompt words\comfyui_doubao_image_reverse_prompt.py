import os
import base64
import json
import time
import requests
import torch
import folder_paths
from PIL import Image
import numpy as np

# 豆包图像反推提示词 ComfyUI 节点
class DoubaoImageReversePrompt:
    """
    豆包图像反推提示词节点 - ComfyUI 版本
    从输入的图像中自动生成适合AI图像生成的提示词
    """
    
    # 节点标题
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "image": ("IMAGE",),
                "api_key": ("STRING", {"default": "", "multiline": False}),
                "api_secret": ("STRING", {"default": "", "multiline": False}),
                "detail_level": (["high", "medium", "low"], {"default": "high"}),
                "language": (["zh", "en"], {"default": "zh"}),
                "style": (["natural", "artistic", "technical"], {"default": "natural"}),
            }
        }
    
    # 节点输出类型
    RETURN_TYPES = ("STRING", "STRING", "STRING")
    RETURN_NAMES = ("原始提示词", "优化提示词", "关键词")
    
    # 节点类别
    CATEGORY = "提示词生成"
    
    # 节点功能名称
    FUNCTION = "generate_prompt"
    
    def generate_prompt(self, image, api_key, api_secret, detail_level="high", language="zh", style="natural"):
        """
        从输入图像生成提示词
        
        Args:
            image: 输入图像张量
            api_key: 豆包API密钥
            api_secret: 豆包API密钥密码
            detail_level: 细节级别
            language: 输出语言
            style: 描述风格
            
        Returns:
            原始提示词, 优化提示词, 关键词
        """
        try:
            # 检查API密钥
            if not api_key or not api_secret:
                raise ValueError("请输入有效的API密钥和密钥密码")
            
            # 将图像张量转换为PIL图像
            pil_image = self._tensor_to_pil(image)
            
            # 将PIL图像转换为base64
            base64_image = self._pil_to_base64(pil_image)
            
            # 发送请求到豆包API
            result = self._call_doubao_api(
                api_key, 
                api_secret, 
                base64_image, 
                detail_level, 
                language, 
                style
            )
            
            # 处理API响应
            processed_result = self._process_response(result)
            
            # 返回结果
            original_prompt = processed_result.get("original_prompt", "")
            optimized_prompt = processed_result.get("optimized_prompt", "")
            keywords = ", ".join(processed_result.get("keywords", []))
            
            return (original_prompt, optimized_prompt, keywords)
            
        except Exception as e:
            # 返回错误信息作为提示词
            error_msg = f"处理失败: {str(e)}"
            return (error_msg, error_msg, error_msg)
    
    def _tensor_to_pil(self, tensor):
        """
        将张量转换为PIL图像
        """
        # 确保张量维度正确
        if len(tensor.shape) == 4:
            tensor = tensor[0]
        
        # 将张量从 [0,1] 范围转换为 [0,255] 范围
        if tensor.max() <= 1.0:
            tensor = tensor * 255
        
        # 转换为numpy数组
        img_np = tensor.cpu().numpy().astype(np.uint8)
        
        # 如果是RGB格式，需要调整通道顺序
        if img_np.shape[0] == 3:
            img_np = np.transpose(img_np, (1, 2, 0))
        
        # 创建PIL图像
        return Image.fromarray(img_np)
    
    def _pil_to_base64(self, image):
        """
        将PIL图像转换为base64字符串
        """
        import io
        buffer = io.BytesIO()
        image.save(buffer, format="PNG")
        return base64.b64encode(buffer.getvalue()).decode('utf-8')
    
    def _call_doubao_api(self, api_key, api_secret, base64_image, detail_level, language, style):
        """
        调用豆包API进行图像分析和提示词生成
        """
        # 构建请求体
        payload = {
            "image": base64_image,
            "parameters": {
                "detail_level": detail_level,
                "language": language,
                "style": style
            }
        }
        
        # 设置请求头
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}:{api_secret}"
        }
        
        # 发送请求
        response = requests.post(
            "https://api.doubao.com/v1/vision/describe",
            headers=headers,
            data=json.dumps(payload)
        )
        
        # 检查响应状态
        if response.status_code != 200:
            raise Exception(f"API请求失败: {response.status_code}, {response.text}")
        
        # 返回响应结果
        return response.json()
    
    def _process_response(self, result):
        """
        处理API响应，提取和格式化提示词
        """
        # 提取基本提示词
        base_prompt = result.get("prompt", "")
        
        # 提取图像分析信息
        image_analysis = result.get("image_analysis", {})
        
        # 提取关键词
        keywords = image_analysis.get("keywords", [])
        
        # 提取风格信息
        style_info = image_analysis.get("style", {})
        
        # 构建优化的提示词
        optimized_prompt = self._optimize_prompt(base_prompt, keywords, style_info)
        
        return {
            "original_prompt": base_prompt,
            "optimized_prompt": optimized_prompt,
            "keywords": keywords,
            "style_info": style_info,
            "full_analysis": image_analysis,
            "timestamp": time.time()
        }
    
    def _optimize_prompt(self, base_prompt, keywords, style_info):
        """
        优化提示词，使其更适合AI图像生成
        """
        # 根据关键词和风格信息优化提示词
        optimized = base_prompt
        
        # 添加关键词强调
        if keywords:
            keyword_str = ", ".join(keywords)
            optimized += f"，重点突出：{keyword_str}"
        
        # 添加风格指导
        if style_info:
            style_type = style_info.get("type", "")
            if style_type:
                optimized += f"，采用{style_type}风格"
        
        return optimized

# 注册节点
NODE_CLASS_MAPPINGS = {
    "DoubaoImageReversePrompt": DoubaoImageReversePrompt
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "DoubaoImageReversePrompt": "豆包图像反推提示词"
}