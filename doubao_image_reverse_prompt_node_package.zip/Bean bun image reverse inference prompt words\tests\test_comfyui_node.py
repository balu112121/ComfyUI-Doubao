import unittest
import os
import sys
from unittest.mock import patch, MagicMock
import tempfile
from PIL import Image

# 添加项目根目录到Python路径
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# 导入ComfyUI节点
from comfyui_doubao_image_reverse_prompt import DoubaoImageReversePromptNode

class TestComfyUIDoubaoImageReversePromptNode(unittest.TestCase):
    def setUp(self):
        # 创建测试节点实例
        self.node = DoubaoImageReversePromptNode()
        
        # 创建临时测试图像
        self.temp_image = tempfile.NamedTemporaryFile(delete=False, suffix='.jpg')
        self.temp_image.close()
        
        # 创建一个简单的测试图像
        test_img = Image.new('RGB', (100, 100), color='blue')
        test_img.save(self.temp_image.name)
        
        # 模拟ComfyUI图像数据结构
        self.mock_image = {
            'image': test_img,
            'width': 100,
            'height': 100
        }
    
    def tearDown(self):
        # 清理临时文件
        os.unlink(self.temp_image.name)
    
    def test_init(self):
        """测试ComfyUI节点初始化"""
        # 验证节点类属性
        self.assertTrue(hasattr(self.node, 'INPUT_TYPES'))
        self.assertTrue(hasattr(self.node, 'RETURN_TYPES'))
        self.assertTrue(hasattr(self.node, 'FUNCTION'))
        self.assertTrue(hasattr(self.node, 'CATEGORY'))
        
        # 验证节点配置
        self.assertEqual(self.node.FUNCTION, 'reverse_infer_prompt')
        self.assertEqual(self.node.CATEGORY, '提示词生成')
        self.assertEqual(self.node.RETURN_TYPES, ('STRING', 'STRING', 'STRING'))
        self.assertEqual(self.node.RETURN_NAMES, ('原始提示词', '优化提示词', '关键词'))
    
    def test_input_types_structure(self):
        """测试节点输入类型结构"""
        input_types = self.node.INPUT_TYPES()
        
        # 验证输入类型包含必要字段
        self.assertIn('required', input_types)
        self.assertIn('optional', input_types)
        
        # 验证必要输入
        required_inputs = input_types['required']
        self.assertIn('image', required_inputs)
        self.assertIn('api_key', required_inputs)
        self.assertIn('api_secret', required_inputs)
        
        # 验证可选输入
        optional_inputs = input_types['optional']
        self.assertIn('detail_level', optional_inputs)
        self.assertIn('language', optional_inputs)
        self.assertIn('style', optional_inputs)
    
    @patch('comfyui_doubao_image_reverse_prompt.DoubaoImageReversePromptNode._encode_image')
    @patch('comfyui_doubao_image_reverse_prompt.DoubaoImageReversePromptNode._call_api')
    def test_reverse_infer_prompt(self, mock_call_api, mock_encode_image):
        """测试ComfyUI节点的反推提示词功能"""
        # 模拟方法返回值
        mock_encode_image.return_value = 'base64_encoded_image'
        mock_call_api.return_value = {
            'original_prompt': '这是一张蓝色的图片',
            'optimized_prompt': '高清细节的蓝色图片，色彩鲜艳，构图简洁',
            'keywords': ['蓝色', '图片', '高清', '细节']
        }
        
        # 调用节点方法
        result = self.node.reverse_infer_prompt(
            self.mock_image,
            'test_api_key',
            'test_api_secret',
            'high',
            'zh',
            'natural'
        )
        
        # 验证结果
        self.assertEqual(len(result), 3)
        self.assertEqual(result[0], '这是一张蓝色的图片')
        self.assertEqual(result[1], '高清细节的蓝色图片，色彩鲜艳，构图简洁')
        self.assertEqual(result[2], '蓝色,图片,高清,细节')
        
        # 验证方法调用
        mock_encode_image.assert_called_once()
        mock_call_api.assert_called_once()
    
    @patch('PIL.Image.Image.save')
    def test_encode_image(self, mock_save):
        """测试图像编码功能"""
        # 由于ComfyUI节点中的_encode_image方法处理的是PIL Image对象
        # 我们需要模拟临时文件保存过程
        with patch('tempfile.NamedTemporaryFile', return_value=MagicMock()):
            encoded_image = self.node._encode_image(self.mock_image)
            
            # 验证结果
            self.assertIsInstance(encoded_image, str)
            self.assertTrue(len(encoded_image) > 0)
            mock_save.assert_called_once()
    
    @patch('requests.Session.post')
    def test_call_api(self, mock_post):
        """测试API调用功能"""
        # 模拟API响应
        mock_response = MagicMock()
        mock_response.json.return_value = {
            'code': 0,
            'data': {
                'prompt': '测试提示词',
                'keywords': ['测试', 'ComfyUI']
            }
        }
        mock_post.return_value = mock_response
        
        # 调用方法
        result = self.node._call_api(
            'test_api_key',
            'test_api_secret',
            'base64_encoded_image',
            'high',
            'zh',
            'natural'
        )
        
        # 验证结果
        self.assertIn('original_prompt', result)
        self.assertIn('optimized_prompt', result)
        self.assertIn('keywords', result)
        self.assertEqual(result['original_prompt'], '测试提示词')
        self.assertEqual(result['keywords'], ['测试', 'ComfyUI'])
        mock_post.assert_called()
    
    def test_optimize_prompt(self):
        """测试提示词优化功能"""
        original_prompt = "这是一张测试图片"
        optimized_prompt = self.node._optimize_prompt(original_prompt, 'high', 'natural')
        
        self.assertIsInstance(optimized_prompt, str)
        self.assertTrue(len(optimized_prompt) >= len(original_prompt))
    
    def test_process_keywords(self):
        """测试关键词处理功能"""
        keywords = ['测试', 'ComfyUI', '图像']
        processed_keywords = self.node._process_keywords(keywords)
        
        self.assertIsInstance(processed_keywords, str)
        self.assertEqual(processed_keywords, '测试,ComfyUI,图像')
    
    @patch('comfyui_doubao_image_reverse_prompt.DoubaoImageReversePromptNode._call_api')
    def test_reverse_infer_prompt_error_handling(self, mock_call_api):
        """测试错误处理"""
        # 模拟API错误
        mock_call_api.side_effect = Exception('API调用失败')
        
        # 调用节点方法并验证错误处理
        with self.assertRaises(Exception) as context:
            self.node.reverse_infer_prompt(
                self.mock_image,
                'test_api_key',
                'test_api_secret'
            )
        
        self.assertIn('API调用失败', str(context.exception))
    
    def test_node_metadata(self):
        """测试节点元数据"""
        # 验证节点显示名称
        self.assertTrue(hasattr(self.node, 'DISPLAY_NAME'))
        self.assertEqual(self.node.DISPLAY_NAME, '豆包图像反推提示词')
        
        # 验证节点描述（如果有）
        if hasattr(self.node, 'DESCRIPTION'):
            self.assertIsInstance(self.node.DESCRIPTION, str)

if __name__ == '__main__':
    unittest.main()