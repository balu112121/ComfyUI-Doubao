import os
import sys
import yaml
import argparse
from doubao_image_reverse_prompt import DoubaoImageReversePromptNode

# 测试脚本主函数
def main():
    """
    豆包图像反推提示词节点测试脚本
    提供简单的命令行界面，用于测试图像反推提示词功能
    """
    # 解析命令行参数
    parser = argparse.ArgumentParser(description='豆包图像反推提示词节点测试工具')
    parser.add_argument('--image', type=str, help='要分析的图像文件路径')
    parser.add_argument('--config', type=str, default='config.yaml', help='配置文件路径')
    parser.add_argument('--detail', type=str, choices=['low', 'medium', 'high'], help='细节级别')
    parser.add_argument('--lang', type=str, choices=['zh', 'en'], help='输出语言')
    parser.add_argument('--style', type=str, choices=['natural', 'artistic', 'technical'], help='描述风格')
    args = parser.parse_args()
    
    # 加载配置文件
    try:
        with open(args.config, 'r', encoding='utf-8') as f:
            config = yaml.safe_load(f)
    except Exception as e:
        print(f"无法加载配置文件 {args.config}: {str(e)}")
        print("请检查配置文件是否存在且格式正确")
        sys.exit(1)
    
    # 检查必要的配置项
    if 'doubao_api_key' not in config or 'doubao_api_secret' not in config:
        print("配置文件中缺少必要的API密钥配置")
        print("请在配置文件中添加 doubao_api_key 和 doubao_api_secret 字段")
        sys.exit(1)
    
    # 检查API密钥是否已设置
    if config['doubao_api_key'] == 'your_api_key_here' or config['doubao_api_secret'] == 'your_api_secret_here':
        print("警告: 您正在使用默认的API密钥占位符")
        print("请在配置文件中替换为您的实际API密钥和密钥密码")
        
        # 询问用户是否继续
        response = input("是否继续使用占位符进行测试？(y/N): ").strip().lower()
        if response != 'y':
            sys.exit(1)
    
    # 获取命令行参数或使用配置文件中的默认值
    image_path = args.image
    detail_level = args.detail or config.get('default_detail_level', 'high')
    language = args.lang or config.get('default_language', 'zh')
    style = args.style or config.get('default_style', 'natural')
    
    # 如果没有提供图像路径，让用户输入
    if not image_path:
        image_path = input("请输入要分析的图像文件路径: ").strip()
    
    # 检查图像文件是否存在
    if not os.path.exists(image_path):
        print(f"错误: 图像文件不存在: {image_path}")
        sys.exit(1)
    
    # 创建节点实例
    try:
        node = DoubaoImageReversePromptNode(
            api_key=config['doubao_api_key'],
            api_secret=config['doubao_api_secret']
        )
    except Exception as e:
        print(f"创建节点实例失败: {str(e)}")
        sys.exit(1)
    
    # 打印测试信息
    print("\n=== 开始测试豆包图像反推提示词功能 ===")
    print(f"图像文件: {image_path}")
    print(f"细节级别: {detail_level}")
    print(f"输出语言: {language}")
    print(f"描述风格: {style}")
    print("====================================")
    
    # 执行测试
    try:
        print("\n正在发送请求到豆包API...")
        result = node.reverse_infer_prompt(
            image_path,
            detail_level=detail_level,
            language=language,
            style=style
        )
        
        # 打印结果
        print("\n=== 测试结果 ===")
        print(f"\n原始提示词:\n{result['original_prompt']}")
        print(f"\n优化提示词:\n{result['optimized_prompt']}")
        print(f"\n关键词:\n{', '.join(result['keywords'])}")
        
        # 可选：保存结果到文件
        if config.get('save_results', False):
            output_dir = config.get('output_dir', './results')
            os.makedirs(output_dir, exist_ok=True)
            
            # 生成输出文件名
            import time
            timestamp = time.strftime('%Y%m%d_%H%M%S')
            base_name = os.path.splitext(os.path.basename(image_path))[0]
            output_file = os.path.join(output_dir, f"{base_name}_{timestamp}_result.json")
            
            # 保存结果
            try:
                with open(output_file, 'w', encoding='utf-8') as f:
                    json.dump(result, f, ensure_ascii=False, indent=2)
                print(f"\n结果已保存到: {output_file}")
            except Exception as e:
                print(f"\n保存结果失败: {str(e)}")
        
        print("\n=== 测试完成 ===")
        
    except Exception as e:
        print(f"\n测试失败: {str(e)}")
        print("\n请检查以下可能的问题:")
        print("1. API密钥和密钥密码是否正确")
        print("2. 网络连接是否正常")
        print("3. 图像文件是否可访问")
        print("4. 豆包API服务是否可用")
        sys.exit(1)

# 添加JSON模块导入，确保脚本可以保存结果
import json

# 执行主函数
if __name__ == "__main__":
    main()