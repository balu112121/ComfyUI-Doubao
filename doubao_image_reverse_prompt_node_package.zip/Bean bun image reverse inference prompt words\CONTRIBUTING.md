# 贡献指南

感谢您对豆包图像反推提示词项目的关注与支持！本指南将帮助您了解如何参与项目贡献。

## 1. 项目概述

豆包图像反推提示词是一个能够从图像自动生成描述性提示词的工具，支持标准 Python 版本和 ComfyUI 节点版本。

## 2. 开发环境设置

### 2.1 克隆项目

```bash
git clone https://your-repository-url/doubao-image-reverse-prompt.git
cd doubao-image-reverse-prompt
```

### 2.2 安装依赖

```bash
pip install -r requirements.txt
pip install -e .  # 以开发模式安装
```

### 2.3 安装开发工具

```bash
pip install pytest black mypy isort flake8
```

## 3. 贡献流程

### 3.1 分支管理

- `main`: 主分支，包含稳定版本代码
- `develop`: 开发分支，新功能开发在该分支进行
- 特性分支: 开发新功能时，从 develop 分支创建特性分支

### 3.2 开发步骤

1. Fork 项目仓库
2. 从 develop 分支创建特性分支
3. 实现功能或修复 bug
4. 编写测试代码
5. 确保代码通过所有测试
6. 提交代码并推送到您的 Fork 仓库
7. 创建 Pull Request 到原始仓库的 develop 分支

## 4. 代码规范

### 4.1 Python 代码规范

- 遵循 PEP 8 规范
- 使用类型注解
- 为公共函数和类添加文档字符串
- 代码风格统一，使用 black 格式化代码

### 4.2 命名规范

- 类名: 使用驼峰命名法 (CamelCase)
- 函数名: 使用下划线命名法 (snake_case)
- 变量名: 使用下划线命名法 (snake_case)
- 常量名: 使用全大写字母加下划线 (ALL_CAPS)

### 4.3 文档规范

- 每个模块、类和公共函数都应有文档字符串
- 文档字符串使用 Google 风格
- 代码中的关键逻辑应有注释说明

## 5. 测试

### 5.1 编写测试

- 为新功能编写单元测试和集成测试
- 测试代码放在 `tests/` 目录下
- 使用 pytest 框架

### 5.2 运行测试

```bash
pytest -v
```

### 5.3 代码覆盖率

```bash
pytest --cov=doubao_image_reverse_prompt tests/
```

## 6. 提交信息规范

提交信息应简洁明了，遵循以下格式:

```
类型(范围): 简短描述

详细描述(可选)

关闭 #issue_number (如果相关)
```

**类型**:
- `feat`: 新功能
- `fix`: 修复 bug
- `docs`: 文档修改
- `style`: 代码风格修改，不影响功能
- `refactor`: 代码重构，不添加功能也不修复 bug
- `test`: 添加或修改测试
- `chore`: 构建过程或辅助工具变动

**示例**:

```
feat: 添加批量处理功能

添加 batch_process 方法，支持同时处理多张图像

close #12
```

## 7. Pull Request 指南

提交 Pull Request 时，请确保:

1. 标题清晰描述您的修改内容
2. 详细说明修改的目的、实现方式和影响范围
3. 关联相关的 Issue
4. 确认所有测试通过
5. 代码通过静态分析检查

## 8. 报告问题

发现问题时，请在 GitHub 上创建 Issue，并包含以下信息:

1. 问题的简要描述
2. 复现步骤
3. 预期行为
4. 实际行为
5. 环境信息 (Python 版本、操作系统等)
6. 相关错误日志或截图

## 9. 功能请求

如您有功能请求，请创建 Feature Request 类型的 Issue，并提供:

1. 功能描述
2. 功能的使用场景
3. 预期的实现方式

## 10. 行为准则

参与本项目的所有贡献者应遵循以下行为准则:

- 尊重其他贡献者
- 接受建设性批评
- 关注问题本身，而非人
- 保持专业性

## 11. 版权与许可

提交代码即表示您同意您的代码将在项目的许可下发布。

## 12. 联系方式

如有任何问题，可以通过以下方式联系项目维护者:

- Email: maintainer@example.com
- GitHub Issues: https://github.com/your-repository-url/issues

感谢您的贡献！